-- Jan 5, 2014 7:35:01 AM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE AD_Column SET Callout='org.compiere.model.CalloutBankStatement.payment',Updated=TO_TIMESTAMP('2014-01-05 07:35:01','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=5216
;

