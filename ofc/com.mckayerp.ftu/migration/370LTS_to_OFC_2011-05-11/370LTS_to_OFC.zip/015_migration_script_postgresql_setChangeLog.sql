-- Jan 8, 2014 12:21:59 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE AD_Table SET IsChangeLog='N',Updated=TO_TIMESTAMP('2014-01-08 12:21:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=1000064
;

-- Jan 8, 2014 12:22:04 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE AD_Table SET IsChangeLog='N',Updated=TO_TIMESTAMP('2014-01-08 12:22:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Table_ID=1000063
;

