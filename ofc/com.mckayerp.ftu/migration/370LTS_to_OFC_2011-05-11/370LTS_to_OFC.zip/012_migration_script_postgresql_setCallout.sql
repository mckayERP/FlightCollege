-- Jan 4, 2014 8:28:25 AM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE AD_Column SET Callout='org.compiere.model.CalloutBankStatement.currency',Updated=TO_TIMESTAMP('2014-01-04 08:28:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=0 WHERE AD_Column_ID=5217
;

