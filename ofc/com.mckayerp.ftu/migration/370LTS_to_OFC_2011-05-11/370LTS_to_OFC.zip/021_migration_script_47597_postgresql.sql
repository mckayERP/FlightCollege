-- Feb 12, 2014 10:47:16 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000061,1002449,TO_TIMESTAMP('2014-02-12 22:47:16','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','O','N','N',TO_TIMESTAMP('2014-02-12 22:47:16','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:47:18 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:47:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002449
;

-- Feb 12, 2014 10:47:44 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000062,1002450,TO_TIMESTAMP('2014-02-12 22:47:44','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','N','N','N',TO_TIMESTAMP('2014-02-12 22:47:44','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:47:51 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='O',Updated=TO_TIMESTAMP('2014-02-12 22:47:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002450
;

-- Feb 12, 2014 10:47:53 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:47:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002450
;

-- Feb 12, 2014 10:48:14 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000063,1002451,TO_TIMESTAMP('2014-02-12 22:48:13','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','O','N','N',TO_TIMESTAMP('2014-02-12 22:48:13','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:48:15 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:48:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002451
;

-- Feb 12, 2014 10:48:49 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000064,1002452,TO_TIMESTAMP('2014-02-12 22:48:49','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','O','N','N',TO_TIMESTAMP('2014-02-12 22:48:49','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:48:55 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:48:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002452
;

-- Feb 12, 2014 10:49:04 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='O',Updated=TO_TIMESTAMP('2014-02-12 22:49:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1001889
;

-- Feb 12, 2014 10:49:06 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:49:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1001889
;

-- Feb 12, 2014 10:49:24 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000066,1002453,TO_TIMESTAMP('2014-02-12 22:49:24','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','O','N','N',TO_TIMESTAMP('2014-02-12 22:49:24','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:49:26 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:49:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002453
;

-- Feb 12, 2014 10:49:51 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000065,1002454,TO_TIMESTAMP('2014-02-12 22:49:51','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','O','N','N',TO_TIMESTAMP('2014-02-12 22:49:51','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:49:52 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:49:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002454
;

-- Feb 12, 2014 10:50:27 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000067,1002455,TO_TIMESTAMP('2014-02-12 22:50:27','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','O','N','N',TO_TIMESTAMP('2014-02-12 22:50:27','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:50:28 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:50:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002455
;

-- Feb 12, 2014 10:50:49 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000068,1002456,TO_TIMESTAMP('2014-02-12 22:50:48','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','O','N','N',TO_TIMESTAMP('2014-02-12 22:50:48','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:50:50 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:50:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002456
;

-- Feb 12, 2014 10:51:05 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000069,1002457,TO_TIMESTAMP('2014-02-12 22:51:05','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','N','N','N',TO_TIMESTAMP('2014-02-12 22:51:05','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:51:10 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='O',Updated=TO_TIMESTAMP('2014-02-12 22:51:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002457
;

-- Feb 12, 2014 10:51:11 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:51:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002457
;

-- Feb 12, 2014 10:51:22 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000070,1002458,TO_TIMESTAMP('2014-02-12 22:51:22','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','N','N','N',TO_TIMESTAMP('2014-02-12 22:51:22','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:51:27 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='O',Updated=TO_TIMESTAMP('2014-02-12 22:51:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002458
;

-- Feb 12, 2014 10:51:33 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:51:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002458
;

-- Feb 12, 2014 10:51:51 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
INSERT INTO C_PeriodControl (AD_Client_ID,AD_Org_ID,C_Period_ID,C_PeriodControl_ID,Created,CreatedBy,DocBaseType,IsActive,PeriodAction,PeriodStatus,Processing,Updated,UpdatedBy) VALUES (1000000,0,1000071,1002459,TO_TIMESTAMP('2014-02-12 22:51:51','YYYY-MM-DD HH24:MI:SS'),100,'CMD','Y','N','N','N',TO_TIMESTAMP('2014-02-12 22:51:51','YYYY-MM-DD HH24:MI:SS'),100)
;

-- Feb 12, 2014 10:51:56 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='O',Updated=TO_TIMESTAMP('2014-02-12 22:51:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002459
;

-- Feb 12, 2014 10:51:57 PM EST
-- I forgot to set the DICTIONARY_ID_COMMENTS System Configurator
UPDATE C_PeriodControl SET PeriodAction='N', PeriodStatus='O',Updated=TO_TIMESTAMP('2014-02-12 22:51:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE C_PeriodControl_ID=1002459
;

